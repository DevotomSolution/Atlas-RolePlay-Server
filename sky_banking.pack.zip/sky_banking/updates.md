# This file includes update instructions and changelogs for new versions

**Current version 1.1**

## Update from 1.0 to 1.1

- Added detecting all atm points automatically
- Added ox_target support

### How to update

- Replace the source/ folder
- Replace config/style.css
- Add following code to config/config.lua:

```lua
Config.ESXCoreResource = "es_extended" -- ESX ONLY
```

- Replace fxmanifest.lua

execute the following sql query:
```sql
ALTER TABLE banking_users
ADD COLUMN totals longtext;
```