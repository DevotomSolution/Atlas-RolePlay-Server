Functions = {}

function Functions.ShowNotification(title, message, type, time) 
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName("("..title..") "..message)
    DrawNotification(false, true)
end

function Functions.ShowHelpNotification(msg, key)
    if key == "E" then key = "~INPUT_CONTEXT~" end
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(key.." "..msg)
    EndTextCommandDisplayHelp(0, 0, 1, -1)
end