SV_Config = {
    webhooks = {
        ["sky_base"] = "https://discord.com/api/webhooks/",
        ["sky_camper"] = "https://discord.com/api/webhooks/",
        ["sky_watchmarket"] = "https://discord.com/api/webhooks/",
        -- Add other Sky-Systems scripts here 
    }
}