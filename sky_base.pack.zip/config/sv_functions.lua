Functions = {}

function Functions.GeneratePlate() 
    math.randomseed(GetGameTimer())
    local plate = string.upper(Sky.Math.GetRandomLetters(3)..' '..Sky.Math.GetRandomNumbers(3))

    local result = nil
    if Config.framework == "esx" then 
        result = Sky.Query('SELECT plate FROM owned_vehicles WHERE plate = ?', {plate})
    elseif Config.framework == "qbcore" then 
        result = Sky.Query('SELECT plate FROM player_vehicles WHERE plate = ?', {plate})
    end

    if result[1] ~= nil then 
        return Functions.GeneratePlate()
    end

    return plate
end

function Functions.GiveVehicle(source, model)
    local plate = Functions.GeneratePlate() 
    if Config.framework == "esx" then 
        -- ESX --
        local xPlayer = ESX.GetPlayerFromId(source)
        Sky.Query('INSERT INTO owned_vehicles (owner, plate, vehicle, stored) VALUES (@owner, @plate, @vehicle, @stored)',
        {
            ['@owner']   = xPlayer.identifier,
            ['@plate']   = plate,
            ['@vehicle'] = json.encode({ model = GetHashKey(model), hash = GetHashKey(model), plate = plate }),
            ['@stored'] = 1
        })
    elseif Config.framework == "qbcore" then
        -- QBCore --
        local PlayerData = QBCore.Functions.GetPlayer(source)
        Sky.Query('INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, state) VALUES (?, ?, ?, ?, ?, ?, ?)', {
            PlayerData.license,
            PlayerData.citizenid, 
            model, 
            GetHashKey(model),
            '{}', 
            plate, 
            0
        })
    end
end

-- default reward table keys = label, sort, name, amount, img
function Functions.GiveCustomReward(source, reward)
    -- Example code
    if reward.sort == "pet" then
        exports["some_petscript"]:GivePet(reward.name, reward.amount)
    end
end
