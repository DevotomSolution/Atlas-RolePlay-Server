Config = {
    -- Global settings for all scripts
    framework = "esx", -- esx, qb, custom - can be customized in config/framework
    sql = "oxmysql", -- oxmysql or mysql-async
    locale = "en", -- locale file to use from config/locales/

    interactionDistance = 2, -- distance from where you can interact with a marker / npc
    defaultBlipSize = 0.8,
    defaultMarkerColor = {
        red = 0,
        green = 255,
        blue = 255,
    },
    enableOXTarget = true, -- enable the OX Target system -> replaces help notification
}