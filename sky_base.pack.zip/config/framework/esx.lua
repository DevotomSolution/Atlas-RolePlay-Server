if Sky.Config.framework == "esx" then
    Sky.FW = {}

    -- Get ESX for new & old versions
    ESX = exports["es_extended"]:getSharedObject()
    if not ESX then
        TriggerEvent("esx:getSharedObject", function(obj)
          ESX = obj
        end)
    end

    function Sky.FW.RegisterUsableItem(name, callback)
        ESX.RegisterUsableItem(name, callback)
    end

    function Sky.FW.IsPlayerOnline(sourceOrIdentifier)
        local xPlayer = ESX.GetPlayerFromId(sourceOrIdentifier)
        if xPlayer == nil then
            xPlayer = ESX.GetPlayerFromIdentifier(sourceOrIdentifier)
            if xPlayer == nil then
                return nil
            else
                return xPlayer.source
            end
        else
            return xPlayer.identifier 
        end 
    end


    function Sky.FW.GetIdentifier(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer.identifier
    end


    function Sky.FW.GetName(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer.name
    end


    function Sky.FW.GetAccountMoney(source, account) 
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer.getAccount(account).money
    end


    function Sky.FW.AddAccountMoney(source, account, amount) 
        local xPlayer = ESX.GetPlayerFromId(source)
        xPlayer.addAccountMoney(account, amount)
    end


    function Sky.FW.RemoveAccountMoney(source, account, amount) 
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer.getAccount(account).money >= amount then
            xPlayer.removeAccountMoney(account, amount)
            return true 
        end
        return false
    end


    function Sky.FW.GetInventoryItems(source) 
        local items = {}

        local xPlayer = ESX.GetPlayerFromId(source)
        inventory = xPlayer.getInventory()

        for _, item in pairs(inventory) do
            if item.count > 0 then
                items[#items + 1] = {
                    name = item.name,
                    label = item.label,
                    amount = item.count
                }
            end
        end

        return items
    end

    function Sky.FW.GetInventoryItem(source, item)
        local xPlayer = ESX.GetPlayerFromId(source)
        local item = xPlayer.getInventoryItem(item)
        if item == nil then
            return nil
        end
        return {
            name = item.name,
            label = item.label,
            amount = item.count
        }
    end

    function Sky.FW.HasItem(source, item, amount) 
        local xPlayer = ESX.GetPlayerFromId(source)
        local item = xPlayer.getInventoryItem(item)
        
        if item == nil then
            return false
        end

        return item.count >= amount
    end


    function Sky.FW.RemoveItem(source, item, amount)
        local xPlayer = ESX.GetPlayerFromId(source)
        local playerItem = xPlayer.getInventoryItem(item) 
        
        if playerItem then
            if playerItem.count > amount then
                xPlayer.removeInventoryItem(item, amount)
                return amount
            else 
                xPlayer.removeInventoryItem(item, playerItem.count)
                return playerItem.count
            end
        else
            return 0
        end
    end
    

    function Sky.FW.AddItem(source, item, amount, force)
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer.canCarryItem(item, amount) or force then
            xPlayer.addInventoryItem(item, amount)
            return true
        end
        return false
    end

    function Sky.FW.GetItemLabel(item)
        return ESX.GetItemLabel(item)
    end


    function Sky.FW.GetJob(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer ~= nil then
            return xPlayer.job.name 
        else 
            return ""
        end
    end

    function Sky.FW.GetGroup(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer ~= nil then
            return xPlayer.getGroup()
        else 
            return ""
        end
    end


    function Sky.FW.GetPlayers() 
        return ESX.GetPlayers() 
    end


    function Sky.FW.IsVehicleOwnedByPlayer(source, plate)
        local xPlayer = ESX.GetPlayerFromId(source)
        local isVehicleOwned = Sky.Query("SELECT * FROM owned_vehicles WHERE plate = @plate AND owner = @owner", {
          ["@plate"] = plate,
          ["@owner"] = xPlayer.identifier,
        })
        if not isVehicleOwned[1] or isVehicleOwned[1].owner ~= xPlayer.identifier then
          return false
        else
          return true
        end
    end
end