if Sky.Config.framework == "qb" then
    Sky.FW = {}

    -- Get Qb
    QBCore = exports['qb-core']:GetCoreObject()

    function Sky.FW.RegisterUsableItem(name, callback)
        QBCore.Functions.CreateUseableItem(name, callback)
    end

    function Sky.FW.IsPlayerOnline(sourceOrIdentifier)
        local xPlayer = QBCore.Functions.GetPlayer(sourceOrIdentifier)
        if xPlayer == nil then
            return nil
        else
            if type(sourceOrIdentifier) == "number" then
                return xPlayer.PlayerData.license 
            else
                return xPlayer.PlayerData.source
            end
        end
    end
    
    function Sky.FW.GetIdentifier(source)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        return xPlayer.PlayerData.license
    end

    function Sky.FW.GetName(source)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        return xPlayer.PlayerData.name
    end

    function Sky.FW.GetAccountMoney(source, account) 
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if account == "money" then
            account = "cash"
        elseif account == "black_money" then
            account = "black"
        end
        return xPlayer.PlayerData.money[account]
    end

    function Sky.FW.AddAccountMoney(source, account, amount) 
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if account == "money" then
            account = "cash"
        elseif account == "black_money" then
            account = "black"
        end
        xPlayer.Functions.AddMoney(account, amount)
    end

    function Sky.FW.RemoveAccountMoney(source, account, amount) 
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if account == "money" then
            account = "cash"
        elseif account == "black_money" then
            account = "black"
        end
        if xPlayer.PlayerData.money[account] >= amount then
            xPlayer.Functions.RemoveMoney(account, amount)
            return true 
        end
        return false
    end

    function Sky.FW.GetInventoryItems(source) 
        local items = {}

        local xPlayer = QBCore.Functions.GetPlayer(source)
        local inventory = xPlayer.PlayerData.items

        for _, item in pairs(inventory) do
            if item.amount > 0 then
                items[#items + 1] = {
                    name = item.name,
                    label = item.label,
                    amount = item.amount
                }
            end
        end

        return items
    end

    function Sky.FW.GetInventoryItem(source, item)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        local playerItem = xPlayer.Functions.GetItemByName(item)
        if playerItem then
            return {
                name = playerItem.name,
                label = playerItem.label,
                amount = playerItem.amount
            }
        else
            return nil
        end
    end

    function Sky.FW.HasItem(source, item, amount) 
        local xPlayer = QBCore.Functions.GetPlayer(source)
        local item = xPlayer.Functions.GetItemByName(item)
        if item == nil then
            return false
        end

        return item.amount >= amount
    end

    function Sky.FW.RemoveItem(source, item, amount)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        local playerItem = xPlayer.Functions.GetItemByName(item)
        
        if playerItem then
            if playerItem.amount > amount then
                xPlayer.Functions.RemoveItem(item, 1)
                return amount
            else 
                xPlayer.Functions.RemoveItem(item, playerItem.amount)
                return playerItem.amount
            end
        else
            return 0
        end
    end


    function Sky.FW.AddItem(source, item, amount, force)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        return xPlayer.Functions.AddItem(item, amount)
    end

    function Sky.FW.GetItemLabel(item)
        return QBCore.Shared.Items[item].label
    end

    function Sky.FW.GetJob(source)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if xPlayer ~= nil then
            return xPlayer.PlayerData.job.name 
        else 
            return ""
        end
    end

    function Sky.FW.GetGroup(source)
        if QBCore.Functions.HasPermission(source, 'god') then
            return "god"
        elseif QBCore.Functions.HasPermission(source, 'admin') then
            return "admin"
        elseif QBCore.Functions.HasPermission(source, 'mod') then
            return "mod"
        else
            return "user"
        end
    end

    function Sky.FW.GetPlayers() 
        return QBCore.Functions.GetPlayers()
    end

    function Sky.FW.IsVehicleOwnedByPlayer(source, plate)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        local isVehicleOwned = Sky.Query("SELECT * FROM player_vehicles WHERE plate = @plate AND license = @license", {
          ["@plate"] = plate,
          ["@license"] = xPlayer.PlayerData.license,
        })
        if not isVehicleOwned[1] or isVehicleOwned[1].license ~= xPlayer.PlayerData.license then
          return false
        else
          return true
        end
    end

end