fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Sky-Systems'
description 'Base resource for all Sky-Systems Scripts'
version '1.1'

escrow_ignore 'config/**'

shared_scripts {
    'config/config.lua',
    'config/functions.lua',
    'source/shared/main.lua',
    'source/shared/modules/*.lua'
}
server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'config/framework/*.lua',
    'config/sv_config.lua',
    'config/sv_functions.lua',
    'source/server/main.lua',
    'source/server/modules/*.lua'
}
client_scripts {
    'source/client/main.lua',
    'source/client/events.lua',
    'source/client/modules/*.lua'
}

files {
	'source/import.lua'
}
dependency '/assetpacks'