# This file includes update instructions and changelogs for new versions

**Current version 1.1**

## Update from 1.0 to 1.1

- Added ox_target support

### How to update

- Replace the source/ folder
- Replace config/ folder
- Replace the fxmanifest.lua
